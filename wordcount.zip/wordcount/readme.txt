=== Simple Word Count ===
Contributors: shobujkhan
Tags: sabuj, personal, sabuj info, personal info, info, information, employee, employee info, employee,s information
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Count all the worlds from your WordPress posts.

== Description ==

Simple Word Count is counting the words fron any WordPress post. It also is being used to count the reading time of a post. And Simple Word Count shows these information under the main content.


== Frequently Asked Questions ==

= Do I need to configure the plugin according to the instruction? =

No, you don't need to configure anything. It's already configured. You just need to active the plugin.

= Is it possible to edit the plugin root file? =

Of course, you can edit the files as you need.

### Features
* Displays the total words of a post at the bottom of the post.
* Display the total reading time of the total words of a post at the bottom of the post.
* There are the options to style the font.
* There are the options to change the tags.
* No need to edit the plugin file.
* By using the filter hooks, plugin option can be modified.
* Completely responsive on any screen.


== Installation ==
To install the plugin, please go to the github link "https://github.com/sabuj-khan/WordCount" and download the main plugin folder. Then you have to upload and install as usual as you do to upload any plugin from your computer. 