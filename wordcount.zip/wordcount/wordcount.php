<?php
/**
 * Plugin Name:       Simple Word Count
 * Plugin URI:        http://mokam24.com/sabuj
 * Description:       Count all the worlds from your WordPress posts
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Mohammad Sabuj Khan
 * Author URI:        http://sabuj.mokam24.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       wordcount
 * Domain Path:       /languages
 */

 function wordcount_text_domain_include(){
    load_plugin_textdomain( 'wordcount', false, dirname(__FILE__)."/languages" );
 }
 add_action('plugins_loaded', 'wordcount_text_domain_include');

 function wordcount_post_words_count($content){
    $stip_word = strip_tags($content);
    $wordn = str_word_count($stip_word);
    $lavel = __('Total Number of words', 'wordcount');

    // Filter hook creating to increase plugin usibily for user
    $lavel = apply_filters('wordcount_heading', $lavel);
    $tags  = apply_filters('wordcount_tags', 'h3');
    $content .= sprintf('<%s>%s : %s</%s>', $tags, $lavel, $wordn, $tags);

    return $content;  
 }
 add_filter('the_content', 'wordcount_post_words_count');

 // Total words reading time 
 function wordcount_podt_words_reading_time($content){
    $stip_word = strip_tags($content);
    $wordn = str_word_count($stip_word);
    $wordmin = floor($wordn/200);
    $wordsec = floor($wordn % 200 / (200/60) );

    $is_visible = apply_filters('wordcount_reading_time', 1);
    if( $is_visible ){
        $lavel = __('Total reading time', 'wordcount');
        // Filter hook creating to increase plugin usibily for user
        $lavel = apply_filters('wordcount_heading_rd', $lavel);
        $tags  = apply_filters('wordcount_tags_rd', 'h3');
        $content .= sprintf('<%s>%s : %s minutes %s seconds </%s>', $tags, $lavel, $wordmin, $wordsec, $tags);
    }
    return $content;
 }
 add_filter('the_content', 'wordcount_podt_words_reading_time');




